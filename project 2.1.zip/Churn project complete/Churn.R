#import the required libraries
library(DataExplorer)
library(corrplot)
library(caTools)
library(caret)
library(ROCR)

#plot the structure of the "Churn" data
plot_str(Churn)

#Check for the missing values
anyNA(Churn)

# Check for Correlated variables.
#if the corelated variables are red then it is highly corelated and is considered as insignificant variables.
#if the corelated variables are blue then it is normal
cor<-corrplot(cor(Churn[sapply(Churn, is.numeric)]))

# Keep the highly correlated variables. i.e all the variables with blue dots.
# Remove the non corelated variables.
# then remvove the unnecessary variables.

Churn$State <-NULL
Churn$Phone<-NULL
Churn$`Area Code`<-NULL
Churn$`Account Length`<-NULL
Churn$`VMail Message`<-NULL
Churn$`Day Mins`<-NULL
Churn$`Eve Mins`<-NULL
Churn$`Night Mins`<-NULL
Churn$`Intl Mins`<-NULL
Churn$`CustServ Calls`<-NULL
Churn$`Int'l Plan`<-NULL
Churn$`Day Calls`<-NULL
Churn$`Eve Calls`<-NULL
Churn$`Night Calls`<-NULL
Churn$`Intl Calls`<-NULL

View(Churn)

# perform logistics regression
set.seed(101)
split<-sample.split(Churn,SplitRatio = 0.75)
split
training<-subset(Churn,split=="TRUE")
testing<-subset(Churn,split=="FALSE")
model<-glm(Churn~.,training,family ="binomial")
summary(model)

#optimize the model by removing independent variables.
# after removing the independent variables from the model make sure the residual deviance should not increase
# and AIC value should decrease.
model<-glm(Churn~.,training,family ="binomial")
summary(model)

# Now predict the values for testing dataset and predict the accuracy of the model type=reponse means
# we want the probability of the testing dataset.

res<-predict(model,testing,type = "response")
res
testing

# Now find the threshold using ROC curve
res<-predict(model,training,type = "response")
ROCRpred=prediction(res,training$Churn)
ROCRperf<-performance(ROCRpred,"tpr","fpr")
plot(ROCRperf,colorize=TRUE,print.cutoffs.at=seq(0.1,by=0.1))

#now the graph says threshold value is 

# Now create the confusion matrix
res<-predict(model,testing,type = "response")
table(Actualvalue=testing$Churn,Predictedvalue=res>0.3)

# Now calculate odds ratio

exp(confint(model))
#The odds ratio says,"what are the odd of an outcome happening as a result of a change in some variable. 
#For each unit increase in international charge, there is probability 15% increase in the likelihood of churning.

